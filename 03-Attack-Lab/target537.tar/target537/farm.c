/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_162(unsigned *p)
{
    *p = 2488826221U;
}

void setval_302(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_424()
{
    return 3284634056U;
}

unsigned getval_429()
{
    return 2428995912U;
}

void setval_102(unsigned *p)
{
    *p = 750999622U;
}

void setval_284(unsigned *p)
{
    *p = 1471923032U;
}

unsigned addval_320(unsigned x)
{
    return x + 3347667161U;
}

unsigned addval_149(unsigned x)
{
    return x + 2425393752U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_231()
{
    return 3532964233U;
}

unsigned getval_379()
{
    return 3767093273U;
}

void setval_122(unsigned *p)
{
    *p = 3286272329U;
}

unsigned addval_250(unsigned x)
{
    return x + 3676362377U;
}

unsigned addval_317(unsigned x)
{
    return x + 3676886665U;
}

void setval_249(unsigned *p)
{
    *p = 3531921035U;
}

unsigned getval_281()
{
    return 2464188744U;
}

void setval_435(unsigned *p)
{
    *p = 2425408129U;
}

unsigned addval_100(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_440(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_397()
{
    return 3526937217U;
}

unsigned getval_135()
{
    return 3374891401U;
}

void setval_161(unsigned *p)
{
    *p = 3525367433U;
}

unsigned addval_344(unsigned x)
{
    return x + 3281043853U;
}

unsigned getval_443()
{
    return 3536112265U;
}

unsigned getval_104()
{
    return 3525364361U;
}

void setval_417(unsigned *p)
{
    *p = 3375939977U;
}

unsigned addval_436(unsigned x)
{
    return x + 2425408137U;
}

void setval_110(unsigned *p)
{
    *p = 2497743176U;
}

void setval_225(unsigned *p)
{
    *p = 3372799641U;
}

void setval_124(unsigned *p)
{
    *p = 2663500425U;
}

void setval_261(unsigned *p)
{
    *p = 3372272265U;
}

void setval_267(unsigned *p)
{
    *p = 2497087864U;
}

void setval_238(unsigned *p)
{
    *p = 3531915689U;
}

unsigned addval_178(unsigned x)
{
    return x + 3374372481U;
}

unsigned getval_459()
{
    return 2447411528U;
}

void setval_244(unsigned *p)
{
    *p = 3223896457U;
}

unsigned getval_400()
{
    return 3221277321U;
}

void setval_232(unsigned *p)
{
    *p = 3804479881U;
}

unsigned addval_422(unsigned x)
{
    return x + 2464188744U;
}

void setval_183(unsigned *p)
{
    *p = 3601445016U;
}

void setval_205(unsigned *p)
{
    *p = 3281043913U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
